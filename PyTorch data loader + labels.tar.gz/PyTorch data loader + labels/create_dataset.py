import numpy as np
import os
import cv2 as cv
import argparse


"./imgs"
# Load the twor rows
dataset = np.loadtxt('labels.txt', comments='#', usecols = (1,2))
names = np.loadtxt('labels.txt', comments='#', usecols = (0))
n = []
for n_i in names:
	t = str(int(n_i)).zfill(5)
	n.append(t)
names = n


labels = dataset[:, 0]
family = dataset[:, 1]

imgs = []
filenames = sorted(os.listdir("./imgs"))
for name in names:
	img_name = os.path.join("./imgs", name + '.jpg')
	imgs.append(cv.imread(img_name, 0))
	


# Now lets save the images and the labels into a file
trainX = np.stack(imgs)
trainY1 = np.stack(labels)
trainY2 = np.stack(family)
os.makedirs('./dataset/', exist_ok=True)
np.save('./dataset/' + '_train_imgs.npy', trainX)
np.save('./dataset/' + '_train_labels.npy', trainY1)
np.save('./dataset/' + '_train_family.npy', trainY2)

# Print the shape of the training images, it should be [B,32,32,3]
# B in this case is eq to 14
print(trainX.shape)
print(trainY1.shape)
