import os
import csv
fid = open("labels.txt", "r")
reader = csv.reader(fid)
data = reader.read()
fid.close()
print(data)
